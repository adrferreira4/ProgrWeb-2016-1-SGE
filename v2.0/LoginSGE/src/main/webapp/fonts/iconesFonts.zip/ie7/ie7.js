/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'iconesFonts\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-home': '&#xe900;',
		'icon-images': '&#xe90e;',
		'icon-film': '&#xe913;',
		'icon-library': '&#xe921;',
		'icon-file-empty': '&#xe924;',
		'icon-file-text2': '&#xe926;',
		'icon-file-picture': '&#xe927;',
		'icon-stack': '&#xe92e;',
		'icon-phone': '&#xe942;',
		'icon-phone-hang-up': '&#xe943;',
		'icon-address-book': '&#xe944;',
		'icon-location': '&#xe947;',
		'icon-location2': '&#xe948;',
		'icon-user': '&#xe971;',
		'icon-users': '&#xe972;',
		'icon-user-plus': '&#xe973;',
		'icon-user-minus': '&#xe974;',
		'icon-user-check': '&#xe975;',
		'icon-lock': '&#xe98f;',
		'icon-unlocked': '&#xe990;',
		'icon-wrench': '&#xe991;',
		'icon-cog': '&#xe994;',
		'icon-cogs': '&#xe995;',
		'icon-stats-bars2': '&#xe99d;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
